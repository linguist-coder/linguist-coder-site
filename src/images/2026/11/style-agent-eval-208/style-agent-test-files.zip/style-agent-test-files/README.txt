AI agent style assignment test files

Everything here is synthetic. OpenAI's Codex wrote the Word files, templates and answer keys
from my spec. I did not open them while building the agent. Their SHA-256 hashes were
recorded before the first run.

files/
  H1.docx H2.docx H3.docx        the Word files (64, 66 and 78 paragraphs)
  template_A/B/C.idml           the templates used for H1, H2 and H3
  H1/H2/H3.key.json             intended style, role and traps for each paragraph
  baseline_name_map.json        the Word style name table used by the name-mapping run
  autostyle_roles.json          role of each function, used to score Auto Style

results/
  <file>_baseline.json          name mapping, one run
  <file>_autostyle.json         Auto Style, one run (Style Pack made from the template)
  <file>_structure_<n>.json     agent with the structural check, runs 1 to 3
  <file>_images_<n>.json        agent with the check and page images, runs 1 to 3
  eval_summary.json             scores for every run
  autostyle_summary.json        scores for the Auto Style runs

In a result file each paragraph has its final style, whether it was flagged and why, and
its character runs. The agent's own summary is in "summary".

InDesign 2026 (21.6) on Windows. Word import: Preserve Styles and Formatting, existing
style definitions win on name clashes. Model: Claude Sonnet 5.5.

The H3 structural-check run 2 was interrupted by a usage limit and run again. Only the
complete run is included.
