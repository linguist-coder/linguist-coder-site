# Read-only: list paragraph styles of the saved test document and score them against answer_key.json.
# Does not touch activeDocument and does not write to the document.
param([string]$DocName = "autostyle_test.indd")
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$app = New-Object -ComObject InDesign.Application
$doc = $null
foreach ($d in $app.Documents) { if ($d.Name -eq $DocName) { $doc = $d } }
if (-not $doc) { Write-Output "NOT OPEN: $DocName"; exit 1 }
$rows = @()
foreach ($s in $doc.Stories) {
  foreach ($p in $s.Paragraphs) {
    $t = ($p.Contents -replace "[\r\n]", "").Trim()
    if ($t.Length -eq 0) { continue }
    $rows += [pscustomobject]@{ style = $p.AppliedParagraphStyle.Name; text = $t.Substring(0, [Math]::Min(50, $t.Length)) }
  }
}
$rows | ConvertTo-Json -Depth 3 | Out-File -Encoding utf8 (Join-Path $here "result.json")
$rows | Format-Table -AutoSize | Out-String -Width 200
