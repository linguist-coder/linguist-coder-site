InDesign Auto Style test files

Everything here is synthetic. I wrote these files for the test.

Test 1
  R4_lamp_guide_messy.docx   the messy Word file (25 paragraphs)
  answer_key.json            intended role of each paragraph
  result.json                paragraph styles after Auto Style with the August preset
  read_result.ps1            the script that read the styles (Windows, reads only)

Test 2
  R4_bracket_structured.docx the Word file styled in Word (22 paragraphs)
  template_test2.idml        the template (8 paragraph styles, 2 character styles)
  answer_key_2.json          intended template style of each paragraph
  result_2.txt               two runs with the mapping the dialog proposed
  result_3.txt               one run with a mapping set by hand:
                             Heading = Chapter Head, Subheading = Section Head,
                             Paragraph = Body, Numbered List 1 = Step,
                             Numbered List 2 = [Basic Paragraph], Bulleted List = Bullet
  read_result_2.ps1          the script that read the styles (Windows, reads only)

Reruns (the numbers in the article): rerun_test1_august.txt, rerun_test2_pack1.txt, rerun_test2_pack2.txt.
InDesign 2026 (21.6) on Windows, Word import set to Preserve Styles and Formatting.
The last line of each rerun file lists the document's paragraph styles.

Earlier runs: result.json, result_2.txt, result_3.txt. Remove Styles and Formatting was on by mistake.
In result_2.txt and result_3.txt each line is:
paragraph style | character styles and bold or italic font styles | first 40 characters

Note on test 1 (added 2026-11-08): answer_key.json labels two Heading1 paragraphs as
"built-in Heading 1". In the .docx all three use the same style ID, and styles.xml defines
that ID twice (as "heading 1" and as "Heading1"). InDesign imports it as Heading1.
The intended role (heading) is the same for all three.
