# Read-only: for each story in the saved test document, list paragraph style + character styles used.
# Two placements (run 1 and run 2) appear as two stories. Does not write to the document.
param([string]$DocName = "autostyle_test2.indd")
$app = New-Object -ComObject InDesign.Application
$js = @"
var d=null; for(var k=0;k<app.documents.length;k++){ if(app.documents[k].name=='$DocName') d=app.documents[k]; }
if(!d){ 'NOT OPEN'; } else {
var out=[];
for(var s=0;s<d.stories.length;s++){ var st=d.stories[s]; if(st.contents.length<20) continue; out.push('=== story '+s);
 for(var i=0;i<st.paragraphs.length;i++){ var p=st.paragraphs[i]; var t=p.contents.replace(/[\r\n]/g,''); if(!t.length) continue;
  var cs={}; var r=p.textStyleRanges; for(var j=0;j<r.length;j++){ var n=r[j].appliedCharacterStyle.name; if(n.indexOf('[')!=0) cs[n]=1; if(r[j].fontStyle.match(/Bold|Italic/)) cs['local:'+r[j].fontStyle]=1; }
  var a=[]; for(var x in cs) a.push(x);
  out.push(p.appliedParagraphStyle.name+' | '+a.join(',')+' | '+t.substr(0,40)); } }
out.join('\n'); }
"@
$app.DoScript($js, 1246973031)
